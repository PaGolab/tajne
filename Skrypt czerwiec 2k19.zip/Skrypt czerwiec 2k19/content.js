console.log("U mnie dziala");//window.location.hostname=="moodle.zsl.poznan.pl"
var url = chrome.extension.getURL("QnA.json");
var json=[];
var save=false;
var data;
$.getJSON( url, function(data) {
  console.log( data);
  for(var i=0; i<data.length; i++)
  {
	  json[i]=data[i];
  }
  
 });

//var QnA = JSON.parse(json);
//console.log(QnA);

	//dodaj pytanie (multichoise[index pytania], iterator)
function addanswer(mc,index){
	
	var q=mc[index].getElementsByClassName("content")[0].getElementsByClassName("qtext")[0].textContent.trim();//zczytuje pytanie z bazy przy kliknietym przycisku 
	console.log(q);
	var correctAnswer=mc[index].getElementsByClassName("content")[0].getElementsByClassName("c1 text correct")[0].textContent.trim();
	var exist=false;
	for (var i=0; i<json.length; i++) 
						{
							var object=json[i];
							if(object.question==q)
							{
								exist=true;
							}
							
						}
	if(exist==false){
		
	json.push(
	{ question: q ,
	 answer: correctAnswer });
	 console.log(json);
	 
	 save=true;
	 }
}

	//console.log(json);

function download(){
var hiddenElement = document.createElement('a');
					hiddenElement.href = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(json));
					hiddenElement.target = '_blank';
					hiddenElement.download = 'QnA.json';
					 hiddenElement.click();
					 }
var mc = document.getElementsByClassName("multichoice");
			for(var i=0;i<mc.length;i++){
				
				(function () {
					var j = i;
						
					var grade;
				
					var lookup =document.getElementsByClassName("main")[0]
					if (lookup === undefined || lookup === null) {}
					else
					{
					lookup.onclick =function()
					{
					download();
					}}
					var finish=document.getElementsByClassName("singlebutton")[1];
					var closewindow =document.getElementsByClassName("controlls");
					if (closewindow === undefined || closewindow === null) {}
					else
					{
					closewindow.onclick =function()
					{
					download();
					}}
					if (finish === undefined || finish === null) {}
					else
					{
					finish.onclick =function()
					{
					download();
					}}
					 
					grade = mc[j].getElementsByClassName("grade")[0];
					grade.onclick = function() {
						var qtxt = mc[j].getElementsByClassName("qtext")[0].textContent.trim();
						
						
						
						var a1 = mc[j].getElementsByClassName("r0")[0].getElementsByClassName("text")[0].textContent.trim().replace("A. ", "");
						var a2 = mc[j].getElementsByClassName("r1")[0].getElementsByClassName("text")[0].textContent.trim().replace("B. ", "");
						var a3 = mc[j].getElementsByClassName("r0")[1].getElementsByClassName("text")[0].textContent.trim().replace("C. ", "");
						var a4 = mc[j].getElementsByClassName("r1")[1].getElementsByClassName("text")[0].textContent.trim().replace("D. ", "");
						//var answer=(podaj odpowiedz dla linijki ktorej numer odpowiada pytaniu cos jak var ans = a[question.indexOf(qtxt)].trim(); var ans=tekst(linijka nr (ans))
						var answer="Nie ma odpowiedzi";
						
						save=false;
						for (var i=0; i<json.length; i++) 
						{
							var object=json[i];
							if(object.question==qtxt)
							{
								answer=json[i].answer;
							}
						}
						if(a1==answer){
							mc[j].getElementsByClassName("r0")[0].getElementsByClassName("control")[0].firstElementChild.checked = true;
							
						}
						else if(a2==answer){
							mc[j].getElementsByClassName("r1")[0].getElementsByClassName("control")[0].firstElementChild.checked = true;
						}
						else if(a3==answer){
							mc[j].getElementsByClassName("r0")[1].getElementsByClassName("control")[0].firstElementChild.checked = true;
						}
						else if(a4==answer){
							mc[j].getElementsByClassName("r1")[1].getElementsByClassName("control")[0].firstElementChild.checked = true;
						}
						else if(mc[j].getElementsByClassName("content")[0].getElementsByClassName("c1 text correct")[0].textContent.trim())
						{
							
							addanswer(mc,j)
						}
						console.log(qtxt);
						console.log(answer);
						
						
					
						
						}
				}());
				
			};
	

